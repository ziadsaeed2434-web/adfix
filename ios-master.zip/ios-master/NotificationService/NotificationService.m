//
//  NotificationService.h
//
//  Copyright (C) 2017 IRCCloud, Ltd.
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.

#import <MobileCoreServices/UTType.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import "NetworkConnection.h"
#import "NotificationService.h"
#import "ColorFormatter.h"
#import "ImageCache.h"

@interface NotificationService ()
@property (nonatomic, strong) void (^contentHandler)(UNNotificationContent *contentToDeliver);
@property (nonatomic, strong) UNMutableNotificationContent *bestAttemptContent;

@end

@implementation NotificationService

- (void)didReceiveNotificationRequest:(UNNotificationRequest *)request withContentHandler:(void (^)(UNNotificationContent * _Nonnull))contentHandler {
    NSURL *attachment = nil;
    NSString *typeHint = UTTypeJPEG.identifier;
    self.contentHandler = contentHandler;
    self.bestAttemptContent = [request.content mutableCopy];
    
#ifdef ENTERPRISE
    NSUserDefaults *d = [[NSUserDefaults alloc] initWithSuiteName:@"group.com.irccloud.enterprise.share"];
#else
    NSUserDefaults *d = [[NSUserDefaults alloc] initWithSuiteName:@"group.com.irccloud.share"];
#endif
    IRCCLOUD_HOST = [d objectForKey:@"host"];
    IRCCLOUD_PATH = [d objectForKey:@"path"];

    if([d boolForKey:@"defaultSound"])
        self.bestAttemptContent.sound = [UNNotificationSound defaultSound];
    
    if([self.bestAttemptContent.categoryIdentifier isEqualToString:@"buffer_me_msg"])
        self.bestAttemptContent.categoryIdentifier = @"buffer_msg";
    
    self.bestAttemptContent.threadIdentifier = [NSString stringWithFormat:@"%@-%@", [[request.content.userInfo objectForKey:@"d"] objectAtIndex:0], [[request.content.userInfo objectForKey:@"d"] objectAtIndex:1]];

    self.bestAttemptContent.summaryArgumentCount = 1;

    if(![d boolForKey:@"disableNotificationPreviews"]) {
        [NetworkConnection sync];
        
        if([request.content.userInfo objectForKey:@"f"]) {
            NSString *fileID = [[request.content.userInfo objectForKey:@"f"] objectAtIndex:0];
            
            if(![NetworkConnection sharedInstance].config) {
                [[NetworkConnection sharedInstance] requestConfigurationWithHandler:^(IRCCloudJSONObject *result) {
                    if(result)
                        [self didReceiveNotificationRequest:request withContentHandler:contentHandler];
                    else
                        self.contentHandler(self.bestAttemptContent);
                }];
                return;
            }
            
            [[NetworkConnection sharedInstance] propertiesForFile:fileID handler:^(IRCCloudJSONObject *o) {
                NSURL *attachment = nil;
                NSString *typeHint = nil;
                if(o) {
                    NSString *type = [o objectForKey:@"mime_type"];
                    typeHint = (__bridge_transfer NSString *)UTTypeCreatePreferredIdentifierForTag(kUTTagClassMIMEType, (__bridge CFStringRef _Nonnull)(type), NULL);
                    
                    if([type hasPrefix:@"image/"]) {
                        attachment = [NSURL URLWithString:[[NetworkConnection sharedInstance].fileURITemplate relativeStringWithVariables:@{@"id":[o objectForKey:@"id"], @"modifiers":[NSString stringWithFormat:@"w%.f", ([UIScreen mainScreen].bounds.size.width/2) * [UIScreen mainScreen].scale]} error:nil]];
                    } else {
                        attachment = [NSURL URLWithString:[o objectForKey:@"url"]];
                    }
                }
                [self attach:attachment typeHint:typeHint];
            }];
            return;
        } else if([d boolForKey:@"thirdPartyNotificationPreviews"]) {
            NSDictionary *extensions = @{@"png":UTTypePNG.identifier,
                                         @"jpg":UTTypeJPEG.identifier,
                                         @"jpeg":UTTypeJPEG.identifier,
                                         @"gif":UTTypeGIF.identifier,
                                         @"m4v":UTTypeAppleProtectedMPEG4Video.identifier,
                                         @"mp4":UTTypeAppleProtectedMPEG4Video.identifier,
                                         @"mov":UTTypeAppleProtectedMPEG4Video.identifier,
                                         @"m4a":UTTypeMPEG4Audio.identifier,
                                         @"mp3":UTTypeMP3.identifier,
                                         @"wav":UTTypeWAV.identifier,
                                         @"avi":UTTypeAVI.identifier,
                                         @"aif":UTTypeAIFF.identifier,
                                         @"aiff":UTTypeAIFF.identifier
                                         };
            NSArray *links;
            [ColorFormatter format:request.content.body defaultColor:[UIColor blackColor] mono:NO linkify:YES server:nil links:&links];

            for(NSTextCheckingResult *r in links) {
                if(r.resultType == NSTextCheckingTypeLink) {
                    NSString *type = [r.URL.pathExtension lowercaseString];
                    if([extensions objectForKey:type]) {
                        attachment = r.URL;
                        typeHint = [extensions objectForKey:type];
                        break;
                    }
                }
            }
        }
    }
    
    [self attach:attachment typeHint:typeHint];
}

- (void)attach:(NSURL *)attachment typeHint:(NSString *)typeHint {
    if(attachment) {
        if([[NSFileManager defaultManager] fileExistsAtPath:[[ImageCache sharedInstance] pathForURL:attachment].path]) {
            [self downloadComplete:attachment typeHint:typeHint];
        } else {
            [[ImageCache sharedInstance] fetchURL:attachment completionHandler:^(BOOL success) {
                [self downloadComplete:attachment typeHint:typeHint];
            }];
        }
    } else {
        self.contentHandler(self.bestAttemptContent);
    }
}

- (void)downloadComplete:(NSURL *)url typeHint:(NSString *)typeHint {
    NSError *error;
    UNNotificationAttachment *a = [UNNotificationAttachment attachmentWithIdentifier:url.lastPathComponent URL:[[ImageCache sharedInstance] pathForURL:url] options:@{UNNotificationAttachmentOptionsTypeHintKey:typeHint} error:&error];
    if(error) {
        NSLog(@"Attachment error: %@", error);
    } else {
        self.bestAttemptContent.attachments = @[a];
    }
    self.contentHandler(self.bestAttemptContent);
}

- (void)serviceExtensionTimeWillExpire {
    self.contentHandler(self.bestAttemptContent);
}

@end
